/*     */ package pixelart.base;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Hashtable;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ public abstract class BaseMovieGenerator
/*     */ {
/*  18 */   private String dossier = "";
/*  19 */   private String prefix = "";
/*  20 */   protected int largeur = 1388;
/*  21 */   protected int hauteur = 768;
/*  22 */   private int frame = 100000;
/*  23 */   protected BufferedImage image = null;
/*  24 */   protected Graphics2D g = null;
/*     */ 
/*     */ 
/*     */   
/*     */   protected Graphics gPrim;
/*     */ 
/*     */ 
/*     */   
/*     */   protected JPanel jPanel;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int frame0;
/*     */ 
/*     */ 
/*     */   
/*     */   private JLabel label;
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseMovieGenerator(int largeur, int hauteur) {
/*  45 */     this();
/*  46 */     this.largeur = largeur;
/*  47 */     this.hauteur = hauteur;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void creerImage() {
/*  53 */     this.image = new BufferedImage(this.largeur, this.hauteur, 1);
/*  54 */     this.g = this.image.createGraphics();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enregistrerImage() throws IOException {
/*  62 */     String filename = String.valueOf(this.dossier) + this.prefix + File.pathSeparator + this.frame + 
/*  63 */       ".jpg";
/*  64 */     this.frame++;
/*  65 */     ImageIO.write(this.image, "jpeg", new File(filename));
/*  66 */     this.g.dispose();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void initMontrerImage() {
/*  72 */     JFrame jjFrame = new JFrame("Video");
/*  73 */     this.jPanel = new JPanel();
/*  74 */     this.jPanel.setMinimumSize(new Dimension(this.largeur, this.hauteur));
/*  75 */     jjFrame.add(this.jPanel);
/*  76 */     jjFrame.setContentPane(this.jPanel);
/*  77 */     jjFrame.setMinimumSize(new Dimension(this.largeur, this.hauteur));
/*  78 */     this.jPanel.setBounds(0, 0, this.largeur, this.hauteur);
/*  79 */     jjFrame.setDefaultCloseOperation(3);
/*  80 */     jjFrame.pack();
/*  81 */     jjFrame.setVisible(true);
/*     */     
/*  83 */     this.gPrim = this.jPanel.getGraphics();
/*  84 */     this.gPrim.setColor(Color.black);
/*  85 */     this.gPrim.drawRect(0, 0, 100, 100);
/*     */   }
/*     */ 
/*     */   
/*     */   public void montrerImage() {}
/*     */ 
/*     */   
/*     */   public String getDossier() {
/*  93 */     return this.dossier;
/*     */   }
/*     */   
/*     */   public String getPrefix() {
/*  97 */     return this.prefix;
/*     */   }
/*     */   
/*     */   public int getLargeur() {
/* 101 */     return this.largeur;
/*     */   }
/*     */   
/*     */   public int getHauteur() {
/* 105 */     return this.hauteur;
/*     */   }
/*     */   
/*     */   public int getFrame() {
/* 109 */     return this.frame;
/*     */   }
/*     */   
/*     */   public BufferedImage getImage() {
/* 113 */     return this.image;
/*     */   }
/*     */   
/*     */   public static void doIt() {}
/*     */   
/* 118 */   public BaseMovieGenerator() { this.frame0 = 0; Directories d = new Directories(); int i = 0; d.setBaseDir(""); d.setMovieDir(getClass()); this.dossier = String.valueOf(d.getMovieDir(getClass())) + File.separator; File f = new File(String.valueOf(this.dossier) + File.separator + "0"); while (f.exists())
/*     */       f = new File(String.valueOf(this.dossier) + File.separator + i++);  this.dossier = String.valueOf(f.getAbsolutePath()) + File.separator; f.mkdirs();
/*     */     this.prefix = "im-";
/*     */     this.largeur = 1388;
/* 122 */     this.hauteur = 768; } public int getFrame0() { return this.frame0; }
/*     */ 
/*     */   
/*     */   public void doit(Hashtable<String, Object> params) {
/* 126 */     this.largeur = Integer.parseInt((String)params.get("largeur"));
/* 127 */     this.hauteur = Integer.parseInt((String)params.get("hauteur"));
/* 128 */     this.frame0 = 0;
/* 129 */     init(params);
/* 130 */     if (params.containsKey("ecran"))
/* 131 */       initMontrerImage(); 
/* 132 */     for (int i = 0; i < ((Integer)params.get("nombre")).intValue(); i++) {
/* 133 */       creerImage();
/* 134 */       initImage();
/* 135 */       dessiner();
/*     */       try {
/* 137 */         enregistrerImage();
/* 138 */         System.out.println(i);
/* 139 */       } catch (IOException e) {
/* 140 */         e.printStackTrace();
/*     */       } 
/* 142 */       this.frame0++;
/* 143 */       this.label.setText(this.frame0);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void doit(Hashtable<String, Object> hashtable, JLabel nbrImages) {
/* 148 */     this.label = nbrImages;
/* 149 */     doit(hashtable);
/*     */   }
/*     */   
/*     */   public abstract void init(Hashtable<String, Object> paramHashtable);
/*     */   
/*     */   public abstract void initImage();
/*     */   
/*     */   public abstract void dessiner();
/*     */   
/*     */   public abstract void modifierImage();
/*     */ }


/* Location:              C:\Users\P1779\Downloads\pixelart.jar!\pixelart\base\BaseMovieGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */